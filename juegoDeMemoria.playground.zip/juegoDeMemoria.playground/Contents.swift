// Juego de Memoria, semana 2

import UIKit

var numeros = 0...100

for i in numeros
{
    var textoNumero=""
    if (i%5==0){
        textoNumero = "Bingo!!! "
    }
    if (i%2==0){
        textoNumero = textoNumero + "par!!! "
    }
    else{
        textoNumero = textoNumero + "impar!!! "
    }
    if (i>29 && i<41){
        textoNumero = textoNumero + "Viva Swift!!! "

    }
    print("# \(i) \(textoNumero)")
}

